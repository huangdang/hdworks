<?php get_header(); ?>

<div id="content">
	<div class="main"><?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		<div id="map">
当前位置：<a href="<?php bloginfo('url'); ?>">首页</a> &raquo;
<?php
if( is_single() ){
$categorys = get_the_category();
$category = $categorys[0];
echo( get_category_parents($category->term_id,true,' &raquo; 正文') );
} elseif ( is_page() ){the_title();
} elseif ( is_category() ){single_cat_title();
} elseif ( is_tag() ){single_tag_title();
} elseif ( is_day() ){the_time('Y年Fj日');
} elseif ( is_month() ){the_time('Y年F');
} elseif ( is_year() ){the_time('Y年');
} elseif ( is_search() ){echo $s.' 的搜索结果';
}?>
		</div>

		<div class="article">
    		<div class="title">
            	<h1><?php the_title(); ?></h1>
                <div class="article_info">作者：<?php the_author() ?> &nbsp; 发布：<?php the_time('Y-m-d H:i') ?> &nbsp; 阅读：<?php post_views(' ', ' 次'); ?> &nbsp; <?php comments_popup_link ('抢沙发','1条评论','%条评论'); ?> &nbsp; <?php edit_post_link('编辑', ' [ ', ' ] '); ?>
                </div>
            </div>
            
            <div class="context">
            	<?php the_content('Read more...'); ?>
                <p>转载请注明本文地址: <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_permalink() ?> | <?php bloginfo('name');?></a></p>
                <p><?php the_tags('标签: ', ', ', ''); ?></p>
            </div>
	    </div>
		<div class="article">
        	<ul>
				<li><?php previous_post_link('【上一篇】%link') ?></li>
				<li><?php next_post_link('【下一篇】%link') ?></li>
            </ul>
		</div>
    
		<div class="article">
			<?php comments_template(); ?>
		</div>
    
	<?php endwhile; else: ?>
	<?php endif; ?>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>