<div id="sidebar">
<div class="widget">
	<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('通用小工具（上）') ) : ?>
	<?php endif; ?>
</div>

<div class="sidebar">
	<h3><span>热评文章</span></h3>
		<div id="tab-content">
			<ul><?php simple_get_most_viewed(); ?></ul>
		</div>
</div>

<div class="widget">
	<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('通用小工具（中）') ) : ?>
	<?php endif; ?>
</div>

<div class="sidebar">
<h3>最新评论</h3>
<ul class="t_comment">
<?php 
$limit_num = '6'; //这里定义显示的评论数量
$my_email = "'" . get_bloginfo ('admin_email') . "'"; //这里是自动检测博主的邮件，实现博主的评论不显示
$rc_comms = $wpdb->get_results("
 SELECT ID, post_title, comment_ID, comment_author, comment_author_email, comment_content
 FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts
 ON ($wpdb->comments.comment_post_ID = $wpdb->posts.ID)
 WHERE comment_approved = '1'
 AND comment_type = ''
 AND post_password = ''
 AND comment_author_email != $my_email
 ORDER BY comment_date_gmt
 DESC LIMIT $limit_num
 ");
$rc_comments = '';
foreach ($rc_comms as $rc_comm) { //get_avatar($rc_comm,$size='50')
$rc_comments .= "<li>". get_avatar($rc_comm,$size='32') ."<span class='zsnos_comment_author'><strong>" . $rc_comm->comment_author . "</strong></span><br/><a href='"
. get_permalink($rc_comm->ID) . "#comment-" . $rc_comm->comment_ID
//. htmlspecialchars(get_comment_link( $rc_comm->comment_ID, array('type' => 'comment'))) // 可取代上一行, 会显示评论分页ID, 但较耗资源
. "' title='在 " . $rc_comm->post_title . " 的评论'>" . mb_substr(strip_tags($rc_comm->comment_content),0,15)
. "</a></li>\n";
}
$rc_comments = convert_smilies($rc_comments);
echo $rc_comments;
?>
</ul>
</div>

<div class="sidebar">
<h3>标签云集</h3>	
	<div class="tag_cloud"><?php wp_tag_cloud('smallest=12&largest=16&unit=px&number=65&orderby=count&order=RAND');?></div>
</div>

<?php if ( is_home() ) { ?>
<div class="sidebar">
<h3>博客统计</h3>
   <ul style="padding-left:16px;">
<li>日志总数：<?php $count_posts = wp_count_posts(); echo $published_posts = $count_posts->publish;?> 篇</li>
<li>评论总数：<?php echo $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->comments where comment_author!='".(get_option('S_user'))."'");?> 篇</li>
<li>分类总数：<?php echo $count_categories = wp_count_terms('category'); ?> 个</li>
<li>标签数量：<?php echo $count_tags = wp_count_terms('post_tag'); ?> 个</li>
<li>链接总数：<?php $link = $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->links WHERE link_visible = 'Y'"); echo $link; ?> 个</li>
<li>最后更新：<?php $last = $wpdb->get_results("SELECT MAX(post_modified) AS MAX_m FROM $wpdb->posts WHERE (post_type = 'post' OR post_type = 'page') AND (post_status = 'publish' OR post_status = 'private')");$last = date('Y-n-j', strtotime($last[0]->MAX_m));echo $last; ?></li>
   </ul></div>
<?php } ?>

<div class="widget">
	<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('通用小工具（下）') ) : ?>
	<?php endif; ?>
</div>

</div>