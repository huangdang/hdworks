<?php get_header(); ?>

<div id="content">
<div class="main">
		<div id="map">
当前位置：<a href="<?php bloginfo('url'); ?>">首页</a> &raquo;
<?php
if( is_single() ){
$categorys = get_the_category();
$category = $categorys[0];
echo( get_category_parents($category->term_id,true,' &raquo; 正文') );
} elseif ( is_page() ){the_title();
} elseif ( is_category() ){single_cat_title();
} elseif ( is_tag() ){single_tag_title();
} elseif ( is_day() ){the_time('Y年Fj日');
} elseif ( is_month() ){the_time('Y年F');
} elseif ( is_year() ){the_time('Y年');
} elseif ( is_search() ){echo $s.' 的搜索结果';
}?>
		</div>

<?php if (have_posts()) : ?><?php while (have_posts()) : the_post(); ?>
  <ul <?php post_class(); ?> id="post-<?php the_ID(); ?>">
    <li>
      <div class="article">
        <div class="entry-content">
        <h2 class="entry-title"><?php if(is_sticky()) : ?><i class="sticky sticky_ordinary"></i><?php else : ?><?php endif; ?><a href="<?php the_permalink() ?>" rel="bookmark" title="详细阅读：<?php the_title_attribute(); ?>"><?php the_title();?></a><span class="new"><?php include('includes/new.php'); ?></span></h2>
        
		<?php if (get_option('S_thumbnail') == 'Display') { ?>
        <?php if (get_option('S_articlepic') == 'Display') { ?>
        <?php include('includes/articlepic.php'); ?>
        <?php { echo ''; } ?>
        <?php } else { include(TEMPLATEPATH . '/includes/thumbnail.php'); } ?>
        <?php { echo ''; } ?>
        <?php } else { } ?>

          <?php
    if(is_singular()){the_content();}else{
    $pc=$post->post_content;
    $st=strip_tags(apply_filters('the_content',$pc));
    if(has_excerpt())
        the_excerpt();
    elseif(preg_match('/<!--more.*?-->/',$pc) || mb_strwidth($st)<150)
        the_content('');
    elseif(function_exists('mb_strimwidth'))
        echo'<p>'
        .mb_strimwidth($st,0,260,' ...')
        .'</p>';
    else the_content();
}?>
        </div>
        <div class="clear"></div>
			<div class="info">
        		<span class="comm">发布：<?php the_time('Y-m-d H:i') ?></span>
				<span class="comm">分类：<?php the_category(', ') ?></span>
				<span class="comm">阅读：<?php post_views('','次'); ?></span>
				<span class="comm">评论：<?php comments_popup_link ('无评论','1条评论','%条评论'); ?></span>
			</div>
				<div class="more"><a style="width: 30px; overflow: hidden;" class="read-more-icon addapted" href="<?php the_permalink() ?>" title="详细阅读：<?php the_title(); ?>" rel="nofollow"><strong style="width: 30px;">Read more</strong><span></span></a></div>
      </div>
    </li>
  </ul><div class="clear"></div>
  <?php endwhile; ?>
  <?php endif; ?>
  <div class="navigation">
    <?php pagination($query_string); ?>
  </div>

</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>
