<div class="clear"></div>

<?php if ( is_home() ) { ?>
	<div class="links">
    	<h3>友情链接</h3>
    		<ul><?php wp_list_bookmarks('orderby=DESC&categorize=0&title_li=&limit=99'); ?></ul>
    </div>
<?php } ?>

<div id="footer">Copyright <?php echo comicpress_copyright(); ?> <a href="<?php bloginfo('url'); ?>" title="<?php bloginfo('name'); ?>"><?php bloginfo('name'); ?></a>. Powered by WordPress. Theme by <a target="_blank" href="http://zhangzifan.com" rel="nofollow"><?php echo wp_get_theme(); ?></a>.
<div id="foot"><?php if (get_option('S_baidu') == 'Display') { ?><a href="<?php echo stripslashes(get_option('S_bddtlink')); ?>" rel="external"><?php echo stripslashes(get_option('S_bddtname')); ?></a><?php { echo '.'; } ?><?php } else { } ?>
 <?php if (get_option('S_google') == 'Display') { ?><a href="<?php echo stripslashes(get_option('S_googledtlink')); ?>" rel="external"><?php echo stripslashes(get_option('S_googledtname')); ?></a><?php { echo '.'; } ?><?php } else { } ?> 
 <?php if (get_option('S_website') == 'Display') { ?><a href="<?php echo stripslashes(get_option('S_websitedtlink')); ?>" rel="external"><?php echo stripslashes(get_option('S_websitedtname')); ?></a><?php { echo '.'; } ?><?php } else { } ?> 
 <?php if (get_option('S_zanzhu') == 'Display') { ?><?php echo stripslashes(get_option('S_zanzhuwhat')); ?>:<a href="<?php echo stripslashes(get_option('S_zanzhulink')); ?>" rel="nofollow" target="_blank"><?php echo stripslashes(get_option('S_zanzhuname')); ?></a><?php { echo '.'; } ?><?php } else { } ?> 
 <?php if (get_option('S_beian') == 'Display') { ?><a href="http://www.miitbeian.gov.cn/" rel="nofollow" target="_blank"><?php echo stripslashes(get_option('S_beianhao')); ?></a><?php { echo '.'; } ?><?php } else { } ?> <?php if (get_option('S_tj') == 'Display') { ?><?php echo stripslashes(get_option('S_tjcode')); ?><?php { echo '.'; } ?>	<?php } else { } ?>
 </div></div>

<?php wp_footer(); ?>


</body>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/comments-ajax.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/realgravatar.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/fancybox.js"></script>
<script type="text/javascript" src="<?php bloginfo('stylesheet_directory'); ?>/js/hoveraccordion.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/creekoo.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory');?>/js/lazyload.js"></script>
</html>